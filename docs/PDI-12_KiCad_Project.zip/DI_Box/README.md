# PDI-12 passive DI box - Project 7

Open `DI_Box.kicad_pro` in KiCad7 or newer. Local symbol/footprint libraries are included.

Start with `Documentation/engineering_report.pdf`, `Documentation/schematic.pdf`, `Documentation/assembly_guide.pdf`, and `Mechanical/enclosure_drawings.pdf`.

The package includes the routed PCB, Gerbers, PTH/NPTH drills, a costed BOM, harness schedule, parametric mechanical sources, STEP solids and machining DXFs. There is no SMT pick-and-place file because the product uses manual THT and panel wiring; `Manufacturing/THT_insertion.csv` is the manual insertion reference.

**Release A: prototype / quotation.** PCB DRC: zero violations and zero unconnected pads. Independent netlist-to-specification and PCB-to-schematic checks passed. Physical audio, real component fit, phantom compatibility and durability have not been measured. Schematic ERC was not available in the KiCad7 CLI used here; run it in KiCad before production. Complete first-article qualification before ordering a manufacturing batch.

Do not change the transformer, grounding, resistor values, insulating carrier or screw penetration limits without revising and revalidating the package. Cost entries are USD planning allowances, not supplier quotations. No certification is claimed.

Scripts in Tools document the source generation and mathematical checks. `build_pcb.py` requires KiCad's pcbnew Python; mechanical generation needs CadQuery and ezdxf, documentation needs reportlab, and validation needs sexpdata. Rebuilding regenerates UUIDs and drawings; keep the supplied release files for reproducibility.
