"""Check exported KiCad connectivity against the specified harness, and calculate pad bounds."""
from pathlib import Path
import json, math, itertools
import sexpdata as sx
P=Path(__file__).resolve().parents[1]
def children(x,key):return [v for v in x if isinstance(v,list) and v and str(v[0])==key]
def child(x,key):return children(x,key)[0]
tree=sx.loads((P/'Validation/full_circuit.net').read_text())
actual={}
for net in children(child(tree,'nets'),'net'):
    name=child(net,'name')[1].lstrip('/')
    for node in children(net,'node'):actual[(child(node,'ref')[1],str(child(node,'pin')[1]))]=name
spec={
'J1':['INPUT_HOT','SIG_GND'],'J2':['INPUT_HOT','SIG_GND'],
'J3':['CHASSIS','OUT_HOT','OUT_COLD','CHASSIS'],
'R1':['INPUT_HOT','PAD_OUT'],'R2':['PAD_OUT','RSH_LO'],
'SW1':['INPUT_HOT','PRI_HOT','PAD_OUT',None,'RSH_LO','SIG_GND'],
'SW2':['CHASSIS','SIG_GND',None],
'T1':['PRI_HOT','SIG_GND','OUT_HOT','OUT_COLD','SIG_GND','CHASSIS','SIG_GND'],
'H1':['INPUT_HOT','SIG_GND'],'H2':['INPUT_HOT','SIG_GND'],
'H3':['PRI_HOT','SIG_GND','OUT_HOT','OUT_COLD','SIG_GND','CHASSIS','SIG_GND'],
'H4':['INPUT_HOT','PRI_HOT','PAD_OUT',None,'RSH_LO','SIG_GND'],
'H5':['SIG_GND','CHASSIS'],'H6':['CHASSIS','OUT_HOT','OUT_COLD','CHASSIS']}
expected={(ref,str(i)):n for ref,ns in spec.items() for i,n in enumerate(ns,1) if n}
# KiCad represents explicitly unconnected pins as unconnected-(...). Ignore those only.
signal_actual={k:v for k,v in actual.items() if not v.startswith('unconnected-')}
assert signal_actual==expected,('Schematic connectivity mismatch',set(expected.items())-set(signal_actual.items()),set(signal_actual.items())-set(expected.items()))
board=sx.loads((P/'DI_Box.kicad_pcb').read_text());boardnets={int(child(x,'net')[1]):None for x in []}
boardnets={int(n[1]):n[2] for n in children(board,'net')}
bp={}
for fp in children(board,'footprint'):
    ref=next(x[2] for x in children(fp,'fp_text') if str(x[1])=='reference')
    if ref.startswith('MH'):continue
    for pad in children(fp,'pad'):
        n=children(pad,'net')
        if n:bp[(ref,str(pad[1]))]=n[0][2].lstrip('/')
pcb_expected={k:v for k,v in expected.items() if k[0].startswith('H') or k[0].startswith('R')}
assert bp==pcb_expected,('PCB-schematic parity mismatch',bp,pcb_expected)
assert len(children(board,'segment'))>0
drc=(P/'Validation/pcb_drc.txt').read_text()
assert '** Found 0 DRC violations **' in drc
assert '** Found 0 unconnected pads **' in drc
Rs,Rsh,Z=9090,1000,141000
parallel=1/(1/Rsh+1/Z);A=parallel/(Rs+parallel)
bounds=[]
for rs,rsh,z in itertools.product([Rs*.99,Rs*1.01],[Rsh*.99,Rsh*1.01],[130000,150000]):
    rp=1/(1/rsh+1/z);bounds.append(20*math.log10(rp/(rs+rp)))
source_ratios={}
for rsource in [0,50,1000,10000]:
    apad=parallel/(rsource+Rs+parallel)
    abypass=Z/(rsource+Z)
    source_ratios[str(rsource)]=20*math.log10(apad/abypass)
Vin=.775*10**(28/20);I=Vin/(Rs+parallel)
report=dict(schematic_connected_pins=len(expected),pcb_connected_pads=len(bp),schematic_connectivity='PASS',pcb_schematic_parity='PASS',pcb_drc='0 violations; 0 unconnected pads',erc='Not run: this validation environment uses KiCad 7 CLI, which has no schematic ERC command. Netlist connectivity was independently checked. Run Inspect > Electrical Rules Checker in KiCad before production.',pad=dict(Rseries_ohm=Rs,Rshunt_ohm=Rsh,Ztransformer_ohm=Z,parallel_ohm=parallel,voltage_ratio=A,attenuation_dB=20*math.log10(A),input_impedance_ohm=Rs+parallel,tolerance_bound_dB=[min(bounds),max(bounds)],incremental_pad_dB_by_source_ohm=source_ratios,series_resistor_power_at_plus28dBu_W=I*I*Rs,shunt_resistor_power_at_plus28dBu_W=(I*parallel)**2/Rsh),turns_ratio_nominal=12,ideal_voltage_gain_dB=-20*math.log10(12),reflected_1k_load_ohm=12**2*1000,physical_test_status='Not built or measured. All audio acceptance limits are prototype targets, not verified product specifications.')
(P/'Validation/validation_summary.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
