from pathlib import Path
import json,math
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape,A4
from reportlab.lib import colors
P=Path(__file__).resolve().parents[1]
g=json.loads((P/'Validation/route_geometry.json').read_text())
W,H=landscape(A4);c=canvas.Canvas(str(P/'Documentation/pcb_drawing.pdf'),pagesize=(W,H))
c.setTitle('PDI-12 PCB fabrication and assembly drawing - Revision A')
S=5.5;OX=50;OY=170
def pt(p):return OX+(p[0]-100)*S, OY+(150-p[1])*S
for page in [1,2]:
    c.setFillColor(colors.HexColor('#14394e'));c.setFont('Helvetica-Bold',18);c.drawString(30,H-35,'PDI-12 PCB fabrication and assembly drawing')
    c.setFillColor(colors.black);c.setFont('Helvetica',10);c.drawString(30,H-55,'Rev A | 80 x 50 x 1.6mm | Component-side view; PCB Y increases down | Units mm')
    c.setStrokeColor(colors.black);c.setLineWidth(1);c.rect(OX,OY,80*S,50*S)
    if page==2:
        for t in g['tracks']:
            c.setStrokeColor(colors.HexColor('#b54040') if t['layer']==0 else colors.HexColor('#326db0'));c.setLineWidth(.4*S);c.line(*pt(t['start']),*pt(t['end']))
    for x,y,n,r in g['pads']:
        a,z=pt((x,y));c.setFillColor(colors.HexColor('#8c969f'));c.setStrokeColor(colors.black);c.setLineWidth(.4);c.circle(a,z,r*S,stroke=1,fill=1);c.setFillColor(colors.white);c.circle(a,z,(.4 if r==.9 else .5)*S,stroke=1,fill=1)
    for x,y,n in g['vias']:
        a,z=pt((x,y));c.setFillColor(colors.HexColor('#596977'));c.circle(a,z,.4*S,stroke=1,fill=1);c.setFillColor(colors.white);c.circle(a,z,.2*S,stroke=1,fill=1)
    for i,(x,y) in enumerate(g['mounts'],1):
        a,z=pt((x,y));c.setFillColor(colors.white);c.circle(a,z,1.6*S,stroke=1,fill=1);c.setFillColor(colors.black);c.setFont('Helvetica',8);c.drawString(a-8,z+13,'MH'+str(i))
    if page==1:
        for name,x,y in [('H1',112,108),('H2',132,108),('H3',124,140),('H4',160,108),('H5',170,128),('H6',158,140)]:
            a,z=pt((x,y));c.setFillColor(colors.black);c.setFont('Helvetica-Bold',10);c.drawCentredString(a,z+18,name)
        for ref,x,y,val in [('R1',118,120,'9.09k'),('R2',138,132,'1.00k')]:
            a,z=pt((x+1.8,y+1.4));c.setFillColor(colors.HexColor('#f0e8d5'));c.rect(a,z,6.4*S,2.8*S,stroke=1,fill=1);c.setFillColor(colors.black);c.setFont('Helvetica-Bold',10);a,z=pt((x+5,y));c.drawCentredString(a,z+19,ref+' '+val)
        for x,y,n,r in g['pads']:
            # Each header's pin numbers are present in native PCB silk; exact pin matrix below.
            pass
    c.setFillColor(colors.black);c.setFont('Helvetica',10);c.drawCentredString(OX+40*S,OY-18,'80.00 +/-0.20');c.saveState();c.translate(OX+80*S+20,OY+25*S);c.rotate(90);c.drawCentredString(0,0,'50.00 +/-0.20');c.restoreState()
    ls=(['ASSEMBLY - component side','H1 input:1 HOT,2 SIG_GND','H2 thru:1 HOT,2 SIG_GND','H3 transformer:','1 YEL,2 ORG,3 RED,4 BRN,','5 BLK,6 WHI,7 GRY','H4 pad switch: pins1-6','Pin4 unused; see Harness.csv','H5 lift:1 SW2.2,2 SW2.1','H6 output:1 chassis,2 hot,','3 cold,4 shell','','All header pins left-to-right.','R1/R2 lead pitch10mm.','MH1-MH4:3.2mm NPTH.'] if page==1 else ['COPPER COMPOSITE / TOP VIEW','Red: front copper','Blue: back copper','','FR4 Tg>=130degC','2 copper layers,1oz/side','Thickness1.60 +/-0.16mm','Lead-free HASL','Green mask / white top silk','','Traces0.40mm','Minimum clearance0.30mm','Via0.80mm / drill0.40mm','Solder-hole drill1.00mm','Resistor drill0.80mm','M3 mount drill3.20mm','','No stencil or SMT process.','Use supplied Gerbers +','PTH and NPTH drill files.'])
    c.setFont('Helvetica',10)
    for i,s in enumerate(ls):c.drawString(555,445-i*16,s)
    c.setFont('Helvetica',9);c.drawString(50,117,'PCB dimension origin: upper-left corner(0,0), X right / Y down. Native KiCad absolute corner=(100,100).')
    c.drawString(50,101,'Enclosure transform: world X=10+xPCB, Y=90-yPCB, PCB underside Z=11. STEP translation=(10,90,11).')
    c.drawString(50,85,'No components on bottom. Header pads are integral wire-solder terminations, not purchased headers.')
    c.drawString(50,69,'Gerber files control copper; drawing is an assembly reference. DRC:0 violations,0 unconnected pads.')
    c.setStrokeColor(colors.grey);c.line(30,40,W-30,40);c.setFont('Helvetica',8);c.drawString(30,24,'PDI-12 | REV A | Prototype / quotation release');c.drawRightString(W-30,24,f'Sheet{page}/2');c.showPage()
c.save()
print('PCB drawing generated')
