"""Generate and route the PCB with KiCad's pcbnew API. Run in KiCad Python."""
import pcbnew as k, json, heapq, math
from pathlib import Path
P=Path(__file__).resolve().parents[1]
M=json.loads((P/'Validation/design_map.json').read_text())
b=k.BOARD(); b.SetFileName(str(P/'DI_Box.kicad_pcb'))
mm=k.FromMM
vec=lambda x,y:k.VECTOR2I(mm(x),mm(y))
netnames=['INPUT_HOT','SIG_GND','PRI_HOT','PAD_OUT','RSH_LO','OUT_HOT','OUT_COLD','CHASSIS']
nets={}
for i,n in enumerate(netnames,1):
    v=k.NETINFO_ITEM(b,'/'+n,i);b.Add(v);nets[n]=v
settings=b.GetDesignSettings()
for attr,val in [('m_MinClearance',.3),('m_TrackMinWidth',.3),('m_ViasMinSize',.8),('m_MinThroughDrill',.4),('m_ViasMinAnnularWidth',.15),('m_CopperEdgeClearance',.5),('m_HoleClearance',.3),('m_HoleToHoleMin',.3),('m_SilkClearance',.15),('m_MinSilkTextHeight',.8),('m_MinSilkTextThickness',.12)]:setattr(settings,attr,mm(val))
b.SetCopperLayerCount(2)
settings.SetBoardThickness(mm(1.6))
def line(x1,y1,x2,y2,layer=k.Edge_Cuts,width=.1,board=b):
    s=(k.FP_SHAPE(board) if isinstance(board,k.FOOTPRINT) else k.PCB_SHAPE(board));s.SetShape(k.SHAPE_T_SEGMENT);s.SetStart(vec(x1,y1));s.SetEnd(vec(x2,y2));s.SetWidth(mm(width));s.SetLayer(layer);board.Add(s)
    if isinstance(board,k.FOOTPRINT):s.SetStart0(vec(x1,y1));s.SetEnd0(vec(x2,y2))
for a,c in [((100,100),(180,100)),((180,100),(180,150)),((180,150),(100,150)),((100,150),(100,100))]:line(*a,*c)
def txt(s,x,y,layer=k.F_SilkS,size=1,board=b):
    t=k.PCB_TEXT(board);t.SetText(s);t.SetPosition(vec(x,y));t.SetTextSize(vec(size,size));t.SetTextThickness(mm(.15));t.SetLayer(layer);board.Add(t)
txt('PDI-12  REV A',140,118,size=1.5)
txt('PASSIVE DI / HARNESS BOARD',140,122,size=1)
txt('80 x 50 mm / THT',140,126,size=.85)
fps={}; pads={}; pad_records=[]; mounts=[]
def makefp(name,n,res=False):
    f=k.FOOTPRINT(b);f.SetFPID(k.LIB_ID('DI_Local',name));f.SetAttributes(k.FP_THROUGH_HOLE)
    for i in range(n):
        p=k.PAD(f);p.SetNumber(str(i+1));p.SetAttribute(k.PAD_ATTRIB_PTH);p.SetShape(k.PAD_SHAPE_CIRCLE if i else k.PAD_SHAPE_RECT)
        p.SetSize(vec(2.2 if not res else 1.8,2.2 if not res else 1.8));p.SetDrillSize(vec(1.0 if not res else .8,1.0 if not res else .8));p.SetLayerSet(k.LSET.AllCuMask()); ls=p.GetLayerSet();ls.AddLayer(k.F_Mask);ls.AddLayer(k.B_Mask);p.SetLayerSet(ls)
        p.SetPos0(vec(i*(10 if res else 4),0));p.SetPosition(vec(i*(10 if res else 4),0));f.Add(p)
    if res:
        for a,c in [((1.8,-1.4),(8.2,-1.4)),((8.2,-1.4),(8.2,1.4)),((8.2,1.4),(1.8,1.4)),((1.8,1.4),(1.8,-1.4))]:line(*a,*c,layer=k.F_SilkS,width=.15,board=f)
    length=(n-1)*(10 if res else 4)
    for a,c in [((-1.7,-2),(length+1.7,-2)),((length+1.7,-2),(length+1.7,2)),((length+1.7,2),(-1.7,2)),((-1.7,2),(-1.7,-2))]:line(*a,*c,layer=k.F_CrtYd,width=.05,board=f)
    f.Reference().SetPosition(vec(length/2,-3.5));f.Reference().SetTextSize(vec(1,1));f.Reference().SetTextThickness(mm(.15));f.Value().SetVisible(False)
    if res:
        model=k.FP_3DMODEL();model.m_Filename='${KIPRJMOD}/Mechanical/resistor_axial.step';f.Add3DModel(model)
    k.FootprintSave(str(P/'DI_Local.pretty'),f)
    return f
for n in [2,4,6,7]:makefp(f'Solder_{n}_P4',n)
makefp('R_Axial_P10',2,True)
positions={'H1':(110,108),'H2':(130,108),'H3':(112,140),'H4':(150,108),'H5':(168,128),'H6':(152,140),'R1':(118,120),'R2':(138,132)}
for c in M['components']:
    if not c['onboard']:continue
    ref=c['ref'];fn=c['footprint'].split(':')[1]
    f=k.FootprintLoad(str(P/'DI_Local.pretty'),fn)
    f.SetFPID(k.LIB_ID('DI_Local',fn))
    f.SetReference(ref);f.SetValue(c['value']);f.SetPath(k.KIID_PATH('/'+M['root']+'/'+c['uuid']));f.SetPosition(vec(*positions[ref]));b.Add(f);fps[ref]=f
    for p in f.Pads():
        n=c['nets'].get(p.GetNumber());
        if n:p.SetNet(nets[n])
        pos=p.GetPosition(); x,y=k.ToMM(pos.x),k.ToMM(pos.y)
        pads[(ref,p.GetNumber())]=(x,y,n)
        pad_records.append((x,y,n, .9 if ref[0]=='R' else 1.1))
for i,(x,y) in enumerate([(104,104),(176,104),(104,146),(176,146)],1):
    f=k.FOOTPRINT(b);f.SetFPID(k.LIB_ID('DI_Local','MountingHole_M3'));f.SetReference('MH'+str(i));f.SetValue('M3 clearance');f.SetPosition(vec(x,y));f.Reference().SetVisible(False);f.Value().SetVisible(False);f.SetAttributes(k.FP_EXCLUDE_FROM_BOM|k.FP_EXCLUDE_FROM_POS_FILES)
    p=k.PAD(f);p.SetAttribute(k.PAD_ATTRIB_NPTH);p.SetShape(k.PAD_SHAPE_CIRCLE);p.SetSize(vec(3.2,3.2));p.SetDrillSize(vec(3.2,3.2));ls=k.LSET.AllCuMask();ls.AddLayer(k.F_Mask);ls.AddLayer(k.B_Mask);p.SetLayerSet(ls);f.Add(p);b.Add(f);mounts.append((x,y))
    k.FootprintSave(str(P/'DI_Local.pretty'),f)

# Deterministic grid router; pad and track obstacles include manufacturing clearance.
G=.5; occupied={0:{},1:{}}; routes=[]; via_records=[]
def grid(x,y):return round((x-100)/G),round((y-100)/G)
def real(x,y):return 100+x*G,100+y*G
def paint(layer,cells,net,r):
    for x,y in cells:
        for dx in range(-r,r+1):
            for dy in range(-r,r+1):
                if dx*dx+dy*dy<=r*r:occupied[layer][(x+dx,y+dy)]=net
for x,y,n,r in pad_records:
    for l in [0,1]:paint(l,[grid(x,y)],n or 'NC',4)
for x,y in mounts:
    for l in [0,1]:paint(l,[grid(x,y)],'MOUNT',5)
def allowed(s,net):
    x,y,l=s
    return 3<=x<=157 and 3<=y<=97 and occupied[l].get((x,y),net)==net
def astar(start,target,net):
    sx,sy=start;tx,ty=target;Q=[];D={};prev={}
    for l in [0,1]:
        s=(sx,sy,l);D[s]=0;heapq.heappush(Q,(abs(sx-tx)+abs(sy-ty),0,s))
    end=None
    while Q:
        _,d,s=heapq.heappop(Q)
        if d!=D[s]:continue
        if s[:2]==target:end=s;break
        x,y,l=s
        choices=[((x+dx,y+dy,l),1) for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]]
        if allowed((x,y,1-l),net):choices.append(((x,y,1-l),12))
        for ns,cost in choices:
            if not allowed(ns,net):continue
            nd=d+cost
            if nd<D.get(ns,1e9):D[ns]=nd;prev[ns]=s;heapq.heappush(Q,(nd+abs(ns[0]-tx)+abs(ns[1]-ty),nd,ns))
    if end is None:raise RuntimeError('Unroutable '+net+' '+str((start,target,pad_records)))
    path=[end]
    while path[-1] in prev:path.append(prev[path[-1]])
    return path[::-1]
for net in ['OUT_HOT','OUT_COLD','RSH_LO','PAD_OUT','PRI_HOT','INPUT_HOT','CHASSIS','SIG_GND']:
    points=sorted({grid(x,y) for x,y,n,r in pad_records if n==net});tree=[points.pop(0)]
    while points:
        _,src,dst=min((abs(a[0]-z[0])+abs(a[1]-z[1]),a,z) for a in tree for z in points)
        path=astar(src,dst,net)
        for l in [0,1]:paint(l,[(x,y) for x,y,ll in path if l==ll],net,2)
        # compress each same-layer straight run into one track segment.
        i=0
        while i<len(path)-1:
            s=path[i];e=path[i+1]
            if s[2]!=e[2]:
                v=k.PCB_VIA(b);v.SetPosition(vec(*real(*s[:2])));v.SetWidth(mm(.8));v.SetDrill(mm(.4));v.SetViaType(k.VIATYPE_THROUGH);v.SetLayerPair(k.F_Cu,k.B_Cu);v.SetNet(nets[net]);b.Add(v);via_records.append((*real(*s[:2]),net));i+=1;continue
            dx,dy=e[0]-s[0],e[1]-s[1];j=i+1
            while j+1<len(path) and path[j+1][2]==s[2] and (path[j+1][0]-path[j][0],path[j+1][1]-path[j][1])==(dx,dy):j+=1
            e=path[j];t=k.PCB_TRACK(b);t.SetStart(vec(*real(*s[:2])));t.SetEnd(vec(*real(*e[:2])));t.SetWidth(mm(.4));t.SetLayer(k.F_Cu if s[2]==0 else k.B_Cu);t.SetNet(nets[net]);b.Add(t);routes.append(dict(net=net,start=real(*s[:2]),end=real(*e[:2]),layer=s[2]));i=j
        tree.append(dst);points.remove(dst)

# Per-pad names on the fabrication layer support manual harness assembly.
for ref,f in fps.items():
    if ref.startswith('H'):
        for p in f.Pads():
            xy=p.GetPosition();txt(p.GetNumber(),k.ToMM(xy.x),k.ToMM(xy.y)+2.8,k.F_SilkS,.8)
b.BuildConnectivity();k.SaveBoard(str(P/'DI_Box.kicad_pcb'),b)
(P/'Validation/route_geometry.json').write_text(json.dumps(dict(pads=pad_records,tracks=routes,vias=via_records,mounts=mounts),indent=2))
print('PCB generated:',len(routes),'tracks,',len(via_records),'vias')
checked=k.LoadBoard(str(P/'DI_Box.kicad_pcb'))
print('DRC report:',k.WriteDRCReport(checked,str(P/'Validation/pcb_drc.txt'),k.EDA_UNITS_MILLIMETRES,True))
