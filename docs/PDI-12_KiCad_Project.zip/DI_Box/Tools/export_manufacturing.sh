#!/usr/bin/env bash
set -euo pipefail
di_project_dir="$(cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$di_project_dir"
kicad-cli sch export pdf -o Documentation/schematic.pdf DI_Box.kicad_sch
kicad-cli sch export netlist -o Validation/DI_Box.net DI_Box.kicad_sch
# Standard PCB netlist omits off-board parts. Export an additional complete
# circuit netlist from a temporary copy that changes only that inclusion flag.
di_net_tmp="$(mktemp -d)"
trap 'rm -rf -- "$di_net_tmp"' EXIT
python3 - "$di_net_tmp/DI_Box.kicad_sch" <<'PY'
import sys
from pathlib import Path
Path(sys.argv[1]).write_text(Path('DI_Box.kicad_sch').read_text().replace('(on_board no)','(on_board yes)'))
PY
kicad-cli sch export netlist -o Validation/full_circuit.net "$di_net_tmp/DI_Box.kicad_sch"
kicad-cli pcb export gerbers -l F.Cu,B.Cu,F.Mask,B.Mask,F.Silkscreen,Edge.Cuts -o Manufacturing/Gerbers/ DI_Box.kicad_pcb
kicad-cli pcb export drill --excellon-separate-th --generate-map -o Manufacturing/Gerbers/ DI_Box.kicad_pcb
kicad-cli pcb export step --force --board-only --user-origin 100x100mm -o Mechanical/pcb.step DI_Box.kicad_pcb
kicad-cli pcb export step --force --user-origin 100x100mm -o Mechanical/pcb_populated.step DI_Box.kicad_pcb
python3 Tools/validate_design.py
echo 'Exports complete. Run schematic ERC and PCB DRC in your installed KiCad before production.'
