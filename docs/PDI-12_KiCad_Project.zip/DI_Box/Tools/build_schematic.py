"""Generate a portable KiCad 7+ schematic with project-local symbols."""
from pathlib import Path
import uuid, json

P = Path(__file__).resolve().parents[1]
uid = lambda: str(uuid.uuid4())
q = lambda x: json.dumps(str(x))
root = uid()
def effects(size=1.27, justify=''):
    return f'(effects (font (size {size} {size})) {justify})'
def prop(name,value,x,y,hide=False):
    return f'(property {q(name)} {q(value)} (at {x} {y} 0) (effects (font (size 1.27 1.27)) {"hide" if hide else ""}))'

defs={}
def block(name,left,right,w=12.7):
    # pin tuple: number, name, net. Graphics coordinates use upward-positive Y.
    n=max(len(left),len(right)); h=max(5.08,(n+1)*2.54)
    pins=[]
    for side,ls in [('L',left),('R',right)]:
        for i,(num,pname) in enumerate(ls):
            y=(len(ls)-1)*2.54/2-i*2.54
            x=-w/2-5.08 if side=='L' else w/2+5.08
            pins.append((str(num),pname,x,y,0 if side=='L' else 180))
    s=f'(symbol {q(name)} (pin_names (offset 0.8)) (in_bom yes) (on_board yes)\n'
    s+=prop('Reference','U',0,h/2+2.54)+prop('Value',name,0,-h/2-2.54)
    s+=f'(symbol {q(name+"_0_1")} (rectangle (start {-w/2} {h/2}) (end {w/2} {-h/2}) (stroke (width 0.254) (type default)) (fill (type background))))\n'
    s+=f'(symbol {q(name+"_1_1")} '
    for num,pname,x,y,a in pins:
        s+=f'(pin passive line (at {x} {y} {a}) (length 5.08) (name {q(pname)} {effects(1.0)}) (number {q(num)} {effects(1.0)}))'
    s+='))'
    defs[name]=(s,pins,h)

block('Jack_TS',[],[(1,'TIP'),(2,'SLEEVE')],10.16)
block('XLR_Male',[(1,'PIN1'),(2,'PIN2+'),(3,'PIN3-'),(4,'SHELL')],[],15.24)
block('JT_DB_E',[(1,'YEL+'),(2,'ORG-'),(5,'BLK'),(7,'GRY / CAN')],[(3,'RED+'),(4,'BRN-'),(6,'WHI')],25.4)
block('Pad_DPDT',[(1,'BYPASS'),(3,'PAD'),(4,'UNUSED'),(6,'PAD_GND')],[(2,'COMMON_A'),(5,'COMMON_B')],25.4)
block('Lift_SPDT',[(1,'GROUND'),(3,'UNUSED')],[(2,'COMMON')],20.32)
block('Resistor',[(1,'')],[(2,'')],7.62)
for n in [2,4,6,7]: block(f'Solder_{n}',[(i,str(i)) for i in range(1,n+1)],[],10.16)

inst=[]; wires=[]; labels=[]; texts=[]; ncs=[]; meta=[]
def wire(x1,y1,x2,y2):
    wires.append(f'(wire (pts (xy {x1} {y1}) (xy {x2} {y2})) (stroke (width 0) (type default)) (uuid {uid()}))')
def add(ref,name,val,x,y,nets,onboard=True,footprint='',mpn=''):
    s,pins,h=defs[name]; u=uid()
    t=f'(symbol (lib_id "DI_Local:{name}") (at {x} {y} 0) (unit 1) (in_bom yes) (on_board {"yes" if onboard else "no"}) (dnp no) (uuid {u})\n'
    t+=prop('Reference',ref,x,y-h/2-5.08)+prop('Value',val,x,y+h/2+5.08)
    t+=prop('Footprint',footprint,x,y,True)+prop('Datasheet','',x,y,True)+prop('MPN',mpn,x,y,True)
    for num,*_ in pins: t+=f'(pin {q(num)} (uuid {uid()}))'
    t+=f'(instances (project "DI_Box" (path "/{root}" (reference {q(ref)}) (unit 1)))))'
    inst.append(t)
    meta.append(dict(ref=ref,uuid=u,value=val,footprint=footprint,nets={str(k):v for k,v in nets.items()},onboard=onboard,mpn=mpn))
    for num,pname,px,py,a in pins:
        xx=x+px; yy=y-py; net=nets.get(int(num))
        if net is None:
            ncs.append(f'(no_connect (at {xx} {yy}) (uuid {uid()}))')
        else:
            end=xx+(-7.62 if a==0 else 7.62)
            wire(xx,yy,end,yy)
            labels.append(f'(label {q(net)} (at {end} {yy} {0 if a==180 else 180}) {effects(1.05,"(justify left bottom)")} (uuid {uid()}))')
def text(s,x,y,size=1.5): texts.append(f'(text {q(s)} (at {x} {y} 0) {effects(size,"(justify left top)")} (uuid {uid()}))')

add('J1','Jack_TS','INPUT / NMJ2HF-S',35,55,{1:'INPUT_HOT',2:'SIG_GND'},False,mpn='NMJ2HF-S')
add('J2','Jack_TS','THRU / NMJ2HF-S',35,95,{1:'INPUT_HOT',2:'SIG_GND'},False,mpn='NMJ2HF-S')
add('R1','Resistor','9.09k / 1% / 0.25W',115,50,{1:'INPUT_HOT',2:'PAD_OUT'},footprint='DI_Local:R_Axial_P10',mpn='MFR-25FBF52-9K09')
add('R2','Resistor','1.00k / 1% / 0.25W',115,85,{1:'PAD_OUT',2:'RSH_LO'},footprint='DI_Local:R_Axial_P10',mpn='MFR-25FBF52-1K')
add('SW1','Pad_DPDT','PAD / 7201SYZBE',135,135,{1:'INPUT_HOT',2:'PRI_HOT',3:'PAD_OUT',4:None,5:'RSH_LO',6:'SIG_GND'},False,mpn='7201SYZBE')
add('T1','JT_DB_E','Jensen JT-DB-E / nominal 12:1',230,70,{1:'PRI_HOT',2:'SIG_GND',3:'OUT_HOT',4:'OUT_COLD',5:'SIG_GND',6:'CHASSIS',7:'SIG_GND'},False,mpn='JT-DB-E')
add('J3','XLR_Male','BALANCED OUT / NC3MD-L-1',340,70,{1:'CHASSIS',2:'OUT_HOT',3:'OUT_COLD',4:'CHASSIS'},False,mpn='NC3MD-L-1')
add('SW2','Lift_SPDT','GROUND / LIFT / 7101SYZBE',275,130,{1:'CHASSIS',2:'SIG_GND',3:None},False,mpn='7101SYZBE')
text('PROJECT 7  |  PDI-12 PASSIVE DI BOX  |  REV A',18,15,2.54)
text('Unbalanced input and parallel thru -> switched pad -> isolated balanced microphone output',18,24,1.6)
text('CIRCUIT / OFF-BOARD PANEL PARTS',18,32,1.8)
text('SW1: BYPASS = 2-1 and 5-4. PAD = 2-3 and 5-6.\nSW2: GROUND = 2-1. LIFT = 2-3 (unused).',18,156,1.4)
text('XLR pin 1 + shell + WHI: permanent chassis bond.\nORG + BLK + GRY: instrument signal ground.\nTransformer can MUST be insulated from chassis.',220,156,1.4)
text('PCB WIRE TERMINATIONS / 4.00 mm PITCH / SOLDERED HARNESS',18,181,1.8)
headers=[('H1',2,'INPUT',35,211,{1:'INPUT_HOT',2:'SIG_GND'}),('H2',2,'THRU',94,211,{1:'INPUT_HOT',2:'SIG_GND'}),('H3',7,'TRANSFORMER',167,219,{1:'PRI_HOT',2:'SIG_GND',3:'OUT_HOT',4:'OUT_COLD',5:'SIG_GND',6:'CHASSIS',7:'SIG_GND'}),('H4',6,'PAD SWITCH',255,219,{1:'INPUT_HOT',2:'PRI_HOT',3:'PAD_OUT',4:None,5:'RSH_LO',6:'SIG_GND'}),('H5',2,'LIFT SWITCH',322,211,{1:'SIG_GND',2:'CHASSIS'}),('H6',4,'XLR OUT',380,215,{1:'CHASSIS',2:'OUT_HOT',3:'OUT_COLD',4:'CHASSIS'})]
for ref,n,v,x,y,ns in headers: add(ref,f'Solder_{n}',v,x,y,ns,footprint=f'DI_Local:Solder_{n}_P4')
text('Bare board solder holes: H4.4 is unused. Panel parts have on_board=no.\nAll pins are passive. No battery, mains inlet, or phantom-power supply.',18,255,1.3)
embedded='\n'.join(s.replace(f'(symbol {q(name)}',f'(symbol "DI_Local:{name}"',1) for name,(s,_,_) in defs.items())
sch=f'(kicad_sch (version 20230121) (generator eeschema) (uuid {root}) (paper "A3")\n(title_block (title "PDI-12 Passive DI - Complete Circuit and Harness") (date "2026-10-05") (rev "A") (company "Project 7 - Manufacturing Proposal") (comment 1 "Prototype / quotation release. Physical validation required before production."))\n(lib_symbols {embedded})\n'+ '\n'.join(wires+labels+ncs+texts+inst)+'\n)'
(P/'DI_Box.kicad_sch').write_text(sch)
(P/'DI_Local.kicad_sym').write_text('(kicad_symbol_lib (version 20220914) (generator kicad_symbol_editor)\n'+'\n'.join(s for s,_,_ in defs.values())+'\n)')
(P/'sym-lib-table').write_text('(sym_lib_table (lib (name "DI_Local") (type "KiCad") (uri "${KIPRJMOD}/DI_Local.kicad_sym") (options "") (descr "Project-local symbols")))')
(P/'fp-lib-table').write_text('(fp_lib_table (lib (name "DI_Local") (type "KiCad") (uri "${KIPRJMOD}/DI_Local.pretty") (options "") (descr "Project-local footprints")))')
(P/'Validation/design_map.json').write_text(json.dumps({'root':root,'components':meta},indent=2))
project={'meta':{'filename':'DI_Box.kicad_pro','version':1},'board':{'design_settings':{'rules':{'min_clearance':0.3,'min_track_width':0.3,'min_via_diameter':0.8,'min_through_hole_diameter':0.4,'min_via_annular_width':0.15,'min_copper_edge_clearance':0.5,'min_hole_clearance':0.3,'min_hole_to_hole':0.3,'min_silk_clearance':0.15,'min_silk_text_height':0.8,'min_silk_text_thickness':0.12},'rule_severities':{}}},'net_settings':{'classes':[{'name':'Default','clearance':0.35,'track_width':0.4,'via_diameter':0.8,'via_drill':0.4,'microvia_diameter':0.3,'microvia_drill':0.1,'diff_pair_width':0.4,'diff_pair_gap':0.35,'diff_pair_via_gap':0.35}],'meta':{'version':3}},'schematic':{'annotate_start_num':0,'drawing':{},'meta':{'version':1}}}
(P/'DI_Box.kicad_pro').write_text(json.dumps(project,indent=2))
print('Schematic generated:',len(meta),'components')
