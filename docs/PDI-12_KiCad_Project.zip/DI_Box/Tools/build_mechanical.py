"""Parametric enclosure and insulated transformer carrier. CadQuery 2.x."""
import cadquery as cq, ezdxf, json
from pathlib import Path
P=Path(__file__).resolve().parents[1]; D=P/'Mechanical'
# Datum: outer front-left-bottom corner. X=150 length, Y=100 depth, Z=up.
pcb_holes=[(14,44),(86,44),(14,86),(86,86)]
carrier_holes=[(100,30),(140,30),(100,60),(140,60)]
lid_holes=[(7,7),(143,7),(7,93),(143,93)]
base=cq.Workplane('XY').box(150,100,50,centered=False)
pocket=cq.Workplane('XY').box(144,94,45,centered=False).translate((3,3,5))
for x,y in lid_holes:
    keep=cq.Workplane('XY').box(8,8,45,centered=False).translate((x-4,y-4,5)); pocket=pocket.cut(keep)
pocket=pocket.edges('|Z').fillet(3)
base=base.cut(pocket)
holes=[]
def cyl(x,y,z,r,h,axis='Z'):
    s=cq.Solid.makeCylinder(r,h,cq.Vector(x,y,z),cq.Vector(*{'X':(1,0,0),'Y':(0,1,0),'Z':(0,0,1)}[axis]));return cq.Workplane(obj=s)
def cut_hole(part,id,x,y,z,d,h,axis='Z',note=''):
    holes.append(dict(id=id,x=x,y=y,z=z,diameter=d,depth=h,axis=axis,note=note))
    return part.cut(cyl(x,y,z,d/2,h,axis))
# Front TS jacks: 11.2 cutout, 18 dia recess inside to leave 2mm panel.
for i,x in enumerate([30,70],1):
    base=cut_hole(base,'J'+str(i),x,-1,28,11.2,5,'Y','11.20 +0.10/-0.00 through; inside spotface diameter 18 depth 1.0')
    base=base.cut(cyl(x,2,28,9,2,'Y'))
# Rear XLR: rear-side vendor pattern; explicit coordinates control orientation.
base=cut_hole(base,'J3',120,96,28,24,5,'Y','24.00 +0.10/-0.00 through')
for i,(x,z) in enumerate([(110.5,16),(129.5,40)],1):
    base=cut_hole(base,'J3_M'+str(i),x,96,z,3.2,5,'Y','3.20 +0.10/-0.00 through; M3 screw and nut')
for i,(x,y) in enumerate(lid_holes,1):
    base=cut_hole(base,'LID_T'+str(i),x,y,38,2.5,12,'Z','M3x0.5 tap from top, 8 minimum full thread; pilot 12 deep')
for tag,ps in [('PCB',pcb_holes),('CARRIER',carrier_holes)]:
    for i,(x,y) in enumerate(ps,1):
        base=cut_hole(base,tag+'_T'+str(i),x,y,1.5,2.5,3.5,'Z','M3x0.5 blind tap from floor, 3.0 thread depth; drill 3.5 deep, no breakthrough')
base=cut_hole(base,'CHASSIS_BOND',140,96,15,3.2,5,'Y','dedicated M3 ring-lug bolt; bare conductive spotfaces inside/outside')
lid=cq.Workplane('XY').box(150,100,3,centered=False).translate((0,0,50))
for x,y in lid_holes:lid=lid.cut(cyl(x,y,49,1.6,5))
for x,y in [(40,38),(110,15)]:lid=lid.cut(cyl(x,y,49,3.25,5))
carrier=cq.Workplane('XY').box(50,40,6,centered=False).translate((95,25,11))
for x,y in carrier_holes:carrier=carrier.cut(cyl(x,y,10,1.6,8))
for y in [45-9.2075,45+9.2075]:carrier=carrier.cut(cyl(120,y,10,1.6,8))
# The two factory wire bundles exit the bottom of the can. Provide clearance
# through the carrier, and6mm free height below it for insulated wire bends.
for x in [120-9.2075,120+9.2075]:carrier=carrier.cut(cyl(x,45,10,4.5,8))
for name,obj in [('enclosure_base',base),('enclosure_lid',lid),('transformer_carrier',carrier)]:cq.exporters.export(obj,str(D/(name+'.step')))
assembly=cq.Assembly(name='PDI_12')
assembly.add(base,name='base_6061',color=cq.Color(.25,.27,.29));assembly.add(lid,name='lid_6061',color=cq.Color(.35,.36,.38))
assembly.add(carrier,name='carrier_acetal',color=cq.Color(.9,.9,.85))
board=cq.Workplane('XY').box(80,50,1.6,centered=False).translate((10,40,11))
for x,y in pcb_holes:board=board.cut(cyl(x,y,10,1.6,4))
assembly.add(board,name='PCB_envelope',color=cq.Color(.08,.43,.25))
can=cyl(120,45,17,14.351,22.1);assembly.add(can,name='T1_envelope_max',color=cq.Color(.62,.62,.65))
# Generic axial-resistor model for KiCad; dimensions are an assembly envelope.
res=cq.Workplane(obj=cq.Solid.makeCylinder(1.25,6.3,cq.Vector(1.85,0,2.2),cq.Vector(1,0,0)))
for start,axis,length in [((0,0,0),(0,0,1),2.2),((0,0,2.2),(1,0,0),1.85),((8.15,0,2.2),(1,0,0),1.85),((10,0,0),(0,0,1),2.2)]:
    res=res.union(cq.Workplane(obj=cq.Solid.makeCylinder(.3,length,cq.Vector(*start),cq.Vector(*axis))))
cq.exporters.export(res,str(D/'resistor_axial.step'))
for name,x,y in [('R1',28,70),('R2',48,58)]:assembly.add(res.translate((x,y,12.6)),name=name+'_envelope',color=cq.Color(.75,.65,.42))
# Conservative panel-part envelopes for clearance checks. Not vendor detail models.
jack_envelopes=[]
for i,x in enumerate([30,70],1):
    env=cq.Workplane('XY').box(21,25,20,centered=False).translate((x-10.5,3,18));jack_envelopes.append(env)
    assembly.add(env,name='J'+str(i)+'_envelope',color=cq.Color(.12,.12,.12))
xlr_env=cq.Workplane('XY').box(32,26,32,centered=False).translate((104,71,12));assembly.add(xlr_env,name='J3_envelope',color=cq.Color(.55,.55,.58))
switches=[]
for i,(x,y) in enumerate([(40,38),(110,15)],1):
    env=cq.Workplane('XY').box(14,14,18,centered=False).translate((x-7,y-7,32));switches.append(env);assembly.add(env,name='SW'+str(i)+'_envelope',color=cq.Color(.2,.2,.22))
assembly.save(str(D/'enclosure_assembly.step'))
cq.exporters.export(base,str(D/'base_preview.svg'),opt={'projectionDir':(1,-1,1),'showHidden':False,'width':900,'height':650})
envelopes=[('PCB',board),('T1',can),('J1',jack_envelopes[0]),('J2',jack_envelopes[1]),('J3',xlr_env),('SW1',switches[0]),('SW2',switches[1])]
collisions=[]
for i,(na,a) in enumerate(envelopes):
    for nb,c in envelopes[i+1:]:
        vol=a.intersect(c).val().Volume()
        if vol>1e-5:collisions.append((na,nb,vol))
if collisions:raise RuntimeError(collisions)
# Machining DXFs are 1:1 planar profiles, units mm. Coordinate tables remain authoritative.
def dxf(name,width,height,cs,rects=[]):
    doc=ezdxf.new('R2010');doc.units=ezdxf.units.MM;m=doc.modelspace()
    m.add_lwpolyline([(0,0),(width,0),(width,height),(0,height)],close=True)
    for x,y,d in cs:m.add_circle((x,y),d/2)
    for x,y,w,h in rects:m.add_lwpolyline([(x,y),(x+w,y),(x+w,y+h),(x,y+h)],close=True,dxfattribs={'layer':'REFERENCE_ONLY'})
    doc.saveas(str(D/name))
dxf('front_cutouts.dxf',150,50,[(30,28,11.2),(70,28,11.2)])
dxf('rear_cutouts_world_XZ.dxf',150,50,[(120,28,24),(110.5,16,3.2),(129.5,40,3.2),(140,15,3.2)])
dxf('lid_cutouts.dxf',150,100,[(x,y,3.2) for x,y in lid_holes]+[(40,38,6.5),(110,15,6.5)])
dxf('floor_tap_centres.dxf',150,100,[(x,y,2.5) for x,y in pcb_holes+carrier_holes])
dxf('carrier_drilling.dxf',50,40,[(x-95,y-25,3.2) for x,y in carrier_holes]+[(25,20-9.2075,3.2),(25,20+9.2075,3.2),(25-9.2075,20,9),(25+9.2075,20,9)])
data=dict(enclosure=dict(L=150,W=100,H=50,lid=3,floor=5,wall=3,pocket_radius=3),pcb_holes=pcb_holes,carrier_holes=carrier_holes,lid_holes=lid_holes,holes=holes,collisions=collisions,pcb_native_step_translation=[10,90,11],pcb_coordinate_transform='World X=10+xPCB; world Y=90-yPCB. PCB x,y measured from native KiCad corner100,100.',carrier_bottom_z=11,carrier_top_z=17,can_top_max_z=39.1,carrier_wire_holes=[[15.7925,20,9],[34.2075,20,9]],release='Prototype / quotation; threaded holes modeled as tap-drill cylinders, apply drawing callouts')
(D/'dimensions.json').write_text(json.dumps(data,indent=2))
(P/'Validation/mechanical_checks.json').write_text(json.dumps({'part_envelope_collisions':collisions,'parts_checked':[n for n,_ in envelopes],'base_solid_valid':base.val().isValid(),'lid_solid_valid':lid.val().isValid(),'carrier_solid_valid':carrier.val().isValid(),'limitation':'Conservative part envelopes; physical first-article fit and cable/solder clearance remain required.'},indent=2))
# Artwork files: guide holes are separate and must not be printed. Millimetre SVG units.
def artwork(name,w,h,labels,guideholes):
    out=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}mm" height="{h}mm" viewBox="0 0 {w} {h}">']
    out+=['<g id="PRINT" fill="white" font-family="DejaVu Sans, sans-serif" text-anchor="middle">']
    for x,y,t,size in labels:out.append(f'<text x="{x}" y="{h-y}" font-size="{size}">{t}</text>')
    out+=['</g>','<g id="GUIDES_DO_NOT_PRINT" display="none" fill="none" stroke="red" stroke-width="0.1">',f'<rect width="{w}" height="{h}"/>']
    for x,y,r in guideholes:out.append(f'<circle cx="{x}" cy="{h-y}" r="{r}"/>')
    out+=['</g></svg>'];(D/name).write_text('\n'.join(out))
artwork('lid_artwork.svg',150,100,[(75,72,'PDI-12',7),(75,62,'PASSIVE TRANSFORMER DI',2.4),(40,53,'-20 dB',2.2),(40,24,'0 dB',2.2),(110,28,'GROUND',2.2),(110,2.5,'LIFT',2.2),(75,87,'NO POWER REQUIRED',1.8)],[(40,38,3.25),(110,15,3.25)]+[(x,y,1.6) for x,y in lid_holes])
artwork('front_artwork.svg',150,50,[(30,41,'INPUT',2.8),(70,41,'THRU',2.8),(112,28,'PDI-12',3.2)],[(30,28,5.6),(70,28,5.6)])
artwork('rear_artwork.svg',150,50,[(30,45,'BALANCED OUT',2.4),(105,30,'XLR: 1 SHIELD / 2 HOT / 3 COLD',1.8),(105,18,'INSTRUMENT / LINE INPUT ONLY',1.7)],[(30,28,12),(39.5,16,1.6),(20.5,40,1.6),(10,15,1.6)])
print('Mechanical CAD generated; no part-envelope overlaps.')
